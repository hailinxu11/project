# order :　处理订单购买业务
# 如: 加入购物车、收藏、购买
# 将自己添加到蓝图中
from flask import Blueprint
order = Blueprint("order", __name__)
from . import views