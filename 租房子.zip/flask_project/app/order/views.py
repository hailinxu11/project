import datetime
import json
import os

from .. models import *
from flask import render_template, session, request, redirect
from . import order


#  显示房屋详情
@order.route('/details')
def details_views():
    # 判断是否有用户登录
    if 'loginid' in session:
        loginid = session['loginid']
        user = Users.query.filter_by(loginid=loginid).first()
        land = Landlord.query.filter_by(loginid=loginid).first()
    # 获取房子的id并查询房源
    id = request.args['id']
    house = House.query.filter_by(id=id).first()
    # 获取图片路径
    imgs = house.images
    # 将字符串转换成列表
    listimg = imgs.split(',')
    while '' in listimg:
        listimg.remove('')
    # 处理订单金额为月租的10%
    money = int(house.price / 10)
    r_id = house.region_id
    c_id = house.city_id
    c = City.query.filter_by(id=c_id).first()
    re = Region.query.filter_by(id=r_id).first()
    con = (house.configure).split(',')
    return render_template('details.html',params=locals())

# 下订单
@order.route('/btnorder')
def btnorder_views():
    # 判断用户是否登录
    if 'loginid' in session:
        loginid = session['loginid']
        user = Users.query.filter_by(loginid=loginid).first()
        h_id = request.args.get('h_id')
        money = request.args.get('money')
        day = datetime.today().date().strftime('%Y%m%d')#获取当前日期作为创建订单日期
        time = datetime.now().strftime('%Y%m%d%H%M%S%f')#获取当前日期字符串作为订单编号
        order = Order()
        if user:
            order.user_id = user.id
            order.number = time
            order.money = money
            order.house_id = h_id
            order.time = day
            db.session.add(order)
            return '0'
    else:
        return '1'

# 处理付款并改变订单状态，改变房源状态
@order.route('/pay')
def pay_views():
    id = request.args['id']
    house = House.query.filter_by(id=id).first()
    order = Order.query.filter_by(house_id=id).first()
    try:
        house.isActive = '已出租'
        db.session.add(house)
        order.status = '已支付'
        db.session.add(order)
        return '200'
    except:
        return '400'

# 判断是否已收藏
@order.route('/iscoll')
def iscoll_views():
    if 'loginid' in session:
        loginid = session['loginid']
        hid = request.args['hid']
        user = Users.query.filter_by(loginid=loginid).first()
        coll = Collect.query.filter(Collect.user_id==user.id,Collect.house_id==hid,Collect.isActive==True).first()
        if coll:
            return '0'
        else:
            return '1'

# 创建收藏
@order.route('/createcoll')
def createcoll_views():
    if 'loginid' in session:
        loginid = session['loginid']
        hid = request.args['hid']
        house = House.query.filter_by(id=hid).first()
        user = Users.query.filter_by(loginid=loginid).first()
        # 查询该房屋的收藏是否存在
        coll = Collect.query.filter(Collect.house_id==hid,Collect.user_id==user.id).first()
        if coll:
            coll.isActive = True
            db.session.add(coll)
        else:
            # 创建收藏
            coll = Collect()
            coll.user_id = user.id
            coll.house_id = house.id
            db.session.add(coll)
        return '0'
    else:
        return '1'


@order.route('/delcoll')
def delcoll_views():
    if 'loginid' in session:
        loginid = session['loginid']
        hid = request.args['hid']
        user = Users.query.filter_by(loginid=loginid).first()
        coll = Collect.query.filter(Collect.house_id==hid,Collect.user_id==user.id).first()
        coll.isActive = False
        db.session.add(coll)
        return '0'
    else:
        return '1'