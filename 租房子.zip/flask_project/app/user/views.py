import datetime,os

from .. models import *
from flask import render_template, session, request, redirect,make_response
from . import user
from .. message import *


# 注册用户或者房东
@user.route('/register',methods=['GET','POST'])
def register0_views():
    if request.method == 'GET':
        resp = make_response(render_template('register.html'))
        url = request.headers.get('Referer','/')
        resp.set_cookie('url',url)
        return resp
    else:
        try:
            loginid = request.form['loginid']
            name = request.form['uname']
            pwd = request.form['pwd']
            email = request.form['uemail']
            tenant = request.form['tenant']
            msg1 = request.form['msg']
            if 'val' in session:
                val = session['val']
                if msg1 == val:
                    if 'check' in request.form:
                        if tenant == '1':
                            user = Users()
                            user.loginid = loginid
                            user.name = name
                            user.pwd = pwd
                            user.email = email
                            db.session.add(user)
                            return '0'
                        else:
                            land = Landlord()
                            land.loginid = loginid
                            land.name = name
                            land.pwd = pwd
                            land.email = email
                            db.session.add(land)
                            return '0'
                    else:
                        return '2'
                else:
                    return '3'
        except:
            return '1'

# 验证账号
@user.route('/01-register',methods=['GET','POST'])
def register1_views():
    loginid = request.form['id']
    if loginid:
        user = Users.query.filter_by(loginid=loginid).first()
        land = Landlord.query.filter_by(loginid=loginid).first()
        if user or land:
            return '0'
        else:
            return '1'
    else:
        return '2'

# 验证昵称
@user.route('/02-register',methods=['GET','POST'])
def register2_views():
    name = request.form['name']
    if name:
        user = Users.query.filter_by(name=name).first()
        land = Landlord.query.filter_by(name=name).first()
        if user or land:
            return '0'
        else:
            return '1'
    else:
        return '2'

# 验证密码是否一致
@user.route('/03-register',methods=['GET','POST'])
def register3_views():
    pwd = request.form['pwd']
    upwd = request.form['upwd']
    if pwd and upwd:
        if pwd == upwd:
            return '1'
        else:
            return '0'
    else:
        return '2'

@user.route('/04-register',methods=['GET','POST'])
def register4_views():
    phone = request.form['msg']
    s = random.sample('1234567890', 4)
    val = ''.join(s)
    msg = Message(phone, val)
    if msg.send() == '200':
        session['val']=val
        return '200'
    else:
        return '400'

# 用户登录
@user.route('/login',methods=['GET','POST'])
def login_views():
    if request.method == 'GET':
        resp = make_response(render_template('login.html'))
        url = request.headers.get('Referer','/')
        resp.set_cookie('url',url)
        return resp
    else:
        loginid = request.form['loginid']
        pwd = request.form['upwd']
        usertype = request.form['usertype']
        # 租客登录
        if usertype == '1':
            user = Users.query.filter_by(loginid=loginid).first()
            if user:
                if pwd == user.pwd:
                    session['loginid']=loginid
                    session['pwd']=pwd
                    url = request.cookies.get('url')
                    url = json.dumps(url)
                    if 'info_pwd' in request.form:
                        tes = make_response()
                        tes.set_cookies('userid',loginid)
                        tes.set_cookies('pwd',pwd)
                    return '0'
                else:
                    return '1'
            else:
                return '2'
        # 房东登录
        else:
            land = Landlord.query.filter_by(loginid=loginid).first()
            if land:
                if pwd == land.pwd:
                    session['loginid'] = loginid
                    session['pwd'] = pwd
                    if 'info_pwd' in request.form:
                        tes = make_response()
                        tes.set_cookies('landid', loginid)
                        tes.set_cookies('pwd', pwd)
                    return '0'
                else:
                    return '1'
            else:
                return '2'

# 退出登录
@user.route('/loginout')
def loginout_views():
    session.clear()
    return redirect('/')

# 第三方微博登录
@user.route('/login/weibo')
def login_weibo():
    return render_template('weibo.html')

# 第三方微信登录
@user.route('/login/weixin')
def login_weixin():
    return render_template('weixin.html')

# 第三方QQ登录
@user.route('/login/qq')
def login_qq():
    return render_template('qq.html')

# 个人中心
@user.route('/userinfo')
def userinfo():
    if 'loginid' in session:
        loginid = session['loginid']
        user = Users.query.filter_by(loginid=loginid).first()
        land = Landlord.query.filter_by(loginid=loginid).first()
        if user:
            orders = Order.query.filter(Order.user_id==user.id,Order.status != '无效').all()
            coll = Collect.query.filter(Collect.user_id==user.id,Collect.isActive==True).all()
            houses = []
            for c in coll:
                h = House.query.filter_by(id=c.house_id).first()
                houses.append(h)
        else:
            houses = House.query.filter(House.landlord_id==land.id,House.isActive != '无效').all()
        return render_template('userinfo.html',params=locals())
    return redirect('/')

# 个人中心-修改用户密码
@user.route('/upuser',methods=['GET','POST'])
def upuser_views():
    if request.method=='GET':
        uid = request.args['id']
        print(uid)
        return render_template('upuser.html',id=uid)
    else:
        id = request.form['uid']
        user = Users.query.filter_by(id=id).first()
        upwd = request.form['upwd']
        if upwd == user.pwd:
            newpwd1 = request.form['newpwd1']
            newpwd2 = request.form['newpwd2']
            if newpwd1 == newpwd2:
                user.pwd = newpwd1
                db.session.add(user)
                return '0'
            else:
                return '1'#新密码不一致
        else:
            return '2'#原始密码错误

# 个人中心-删除订单
@user.route('/delorder')
def delorder_views():
    oid = request.args['oid']
    order = Order.query.filter_by(id=oid).first()
    order.status = '无效'
    db.session.add(order)
    return redirect('/userinfo')

# 获取订单内容
@user.route('/payhouse')
def payhouse_views():
    oid = request.args['oid']
    order = Order.query.filter_by(id=oid).first()
    house = House.query.filter_by(id=order.house_id).first()
    jsonStr = json.dumps(house.to_dict())
    return jsonStr

# 个人中心-支付订单
@user.route('/payorder')
def payorder_views():
    oid = request.args['oid']
    order = Order.query.filter_by(id=oid).first()
    house = House.query.filter_by(id=order.house_id).first()
    order.status = '已支付'
    db.session.add(order)
    house.isActive = '已出租'
    db.session.add(house)
    return redirect('/userinfo')

# 个人中心-删除房源
@user.route('/delhouse')
def delhouse_views():
    hid = request.args['hid']
    house = House.query.filter_by(id=hid).first()
    house.isActive = '无效'
    db.session.add(house)
    return redirect('/userinfo')

# 个人中心-下架房源
@user.route('/outhouse')
def outhouse_views():
    hid = request.args['hid']
    house = House.query.filter_by(id=hid).first()
    house.isActive = '已下架'
    db.session.add(house)
    return redirect('/userinfo')

# 个人中心-上架房源
@user.route('/tophouse')
def tophouse_views():
    hid = request.args['hid']
    house = House.query.filter_by(id=hid).first()
    house.isActive = '已上架'
    db.session.add(house)
    return redirect('/userinfo')


# 个人中心-修改房源信息
@user.route('/uphouse',methods=['GET','POST'])
def uphouse_views():
    if request.method == 'GET':
        hid = request.args['hid']
        house = House.query.filter_by(id=hid).first()
        pro = Province.query.filter_by(id=house.pro_id).first()
        city = City.query.filter_by(id=house.city_id).first()
        region = Region.query.filter_by(id=house.region_id).first()
        return render_template('uphouse.html',params=locals())
    else:
        id = request.form['h_id']
        house = House.query.filter_by(id=id).first()
        house.price = request.form['price']
        house.address = request.form['address']
        house.describe = request.form['describe']
        image = request.files.getlist('photos')
        l = ''
        for img in image:
            # 根据时间生成文件名
            ftime = datetime.now().strftime('%Y%m%d%H%M%S%f')
            # 根据源文件获取扩展名
            ext = img.filename.split('.')[-1]
            # 拼接完整的文件名
            filename = ftime + '.' + ext
            # 动态得到文件路径
            bashir = os.path.dirname(os.path.dirname(__file__))
            # 拼接完整的路径名
            upload_path = os.path.join(bashir, 'static/images/upload', filename)
            # 保存至文件
            img.save(upload_path)
            # 定义爆粗进数据库的文件路径
            image_url = '/static/images/upload/' + filename
            l += image_url + ','
        house.images = l  # 保存文件路径至数据库
        house.phone = request.form['phone']
        db.session.add(house)
        return redirect('/userinfo')