# user :　处理用户相关业务
# 如: 注册、登录、注销等
# 将自己添加到蓝图中
from flask import Blueprint
user = Blueprint("user", __name__)
from . import views