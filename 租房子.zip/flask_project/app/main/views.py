# 处理商城首页的显示与其他业务
import datetime
import json
import os

from .. models import *
from flask import render_template, session, request, redirect
from . import main

url_barsh = '/'#声明一个路由变量

# 首页视图,获取省份城市信息
@main.route("/",methods=['GET','POST'])
def index_views():
    if request.method=='GET':
        pro = Province.query.all()
        house = House.query.filter_by(isActive='已上架').all()
        if 'loginid' in session:
            loginid = session['loginid']
            user = Users.query.filter_by(loginid=loginid).first()
            land = Landlord.query.filter_by(loginid=loginid).first()
        return render_template('index.html', params=locals())
    else:
        c_id = request.form['id']
        if c_id:
            house = House.query.filter(House.city_id==c_id,House.isActive=='已上架').all()
            l=[]
            for h in house:
                l.append(h.to_dict())
            jsonStr = json.dumps(l)
        else:
            house = House.query.filter(House.isActive=='已上架').all()
            l = []
            for h in house:
                l.append(h.to_dict())
            jsonStr = json.dumps(l)
        return jsonStr

# 动态获取省份
@main.route('/upload')
def upload_views():
    url_barsh = request.headers.get('Referer','/')
    pros = Province.query.all()
    if 'loginid' in session:
        loginid = session['loginid']
        land = Landlord.query.filter_by(loginid=loginid).first()
        return render_template('upload.html', params=locals())
    else:
        return redirect(url_barsh)

# 动态获取城市
@main.route('/01-upload')
def upload1_views():
    p_id = request.args.get('id')
    city = City.query.filter_by(pro_id=p_id).all()
    l = []
    for c in city:
        l.append(c.to_dict())
    jsonStr = json.dumps(l)
    return jsonStr

# 动态获取区域
@main.route('/02-upload')
def upload2_views():
    c_id = request.args.get('id')
    region = Region.query.filter_by(city_id=c_id).all()
    l = []
    for r in region:
        l.append(r.to_dict())
    jsonStr = json.dumps(l)
    return jsonStr

#  上传房源
@main.route('/03-upload',methods=['GST','POST'])
def upload3_views():
    try:
        loginid = session['loginid']
        land = Landlord.query.filter_by(loginid=loginid).first()
        house = House()
        house.pro_id = request.form['pro']
        house.city_id = request.form['city']
        house.region_id = request.form['region']
        house.title = request.form['title']
        house.times = datetime.today().date()
        type1 = request.form['type1']
        type2 = request.form['type2']
        type3 = request.form['type3']
        house.type = type1+'-'+type2+'-'+type3
        house.acreage = request.form['acreage']
        floor1 = request.form['floor1']
        floor2 = request.form['floor2']
        house.floor = floor1+'/'+floor2
        house.orientation = request.form['orientation']
        house.price = request.form['price']
        house.payment = request.form['payment']
        # 获取房屋配置
        configure = request.form.getlist('configure')
        # 将列表转化成字符串
        house.configure = ','.join(configure)
        # 获取房屋卖点
        advantage = request.form.getlist('advantage')
        # 将列表转化成字符串
        house.advantage = ','.join(advantage)
        house.address = request.form['address']
        house.describe = request.form['describe']
        image = request.files.getlist('photos')
        l = ''
        for img in image:
            # 根据时间生成文件名
            ftime = datetime.now().strftime('%Y%m%d%H%M%S%f')
            # 根据源文件获取扩展名
            ext = img.filename.split('.')[-1]
            # 拼接完整的文件名
            filename = ftime + '.' + ext
            # 动态得到文件路径
            bashir = os.path.dirname(os.path.dirname(__file__))
            # 拼接完整的路径名
            upload_path = os.path.join(bashir,'static/images/upload', filename)
            # 保存至文件
            img.save(upload_path)
            # 定义爆粗进数据库的文件路径
            image_url = '/static/images/upload/'+filename
            l += image_url+','
        house.images = l#保存文件路径至数据库
        house.phone = request.form['phone']
        house.landlord_id = land.id
        db.session.add(house)
        return '1'
    except:
        return '0'

# 搜索小区并返回结果
@main.route('/query')
def query_views():
    rname = request.args.get('data')
    c_id = request.args.get('city')
    if rname and c_id:
        region = House.query.filter(House.city_id==c_id,House.title.like('%'+rname+'%')).all()
        l = []
        for r in region:
            l.append(r.to_dict())
        jsonStr = json.dumps(l)
        return jsonStr
    return '1'

# 根据搜索查找房源
@main.route('/queryhouse')
def queryhouse_views():
    title = request.args.get('date')
    house = House.query.filter(House.isActive=='已上架',House.title.like('%'+title+'%')).all()
    l = []
    for h in house:
        l.append(h.to_dict())
    jsonStr = json.dumps(l)
    return jsonStr

# 多条件查找
@main.route('/queryby')
def queryby_views():
    c_id = request.args.get('cid')
    a = request.args.get('a')
    a = a.split(',')
    p = request.args.get('p')
    p = p.split(',')
    t = request.args.get('t')
    r = request.args.get('r')
    if int(t) >0 and int(r) > 0:
        house = House.query.filter(House.isActive=='已上架',House.city_id==c_id,
                               House.region_id == r,
                               House.acreage.between(a[0],[1]),
                               House.price.between(p[0],p[1]),
                               House.type.like(t+'%'),
                               ).all()
    elif int(t) >0 and int(r)==0:
        house = House.query.filter(House.isActive=='已上架', House.city_id == c_id,
                                   House.acreage.between(int(a[0]), int(a[1])),
                                   House.price.between(int(p[0]), int(p[1])),
                                   House.type.like(t + '%')
                                   ).all()
    elif int(t)==0 and int(r) > 0:
        house = House.query.filter(House.isActive=='已上架', House.city_id == c_id,
                                   House.acreage.between(int(a[0]), int(a[1])),
                                   House.price.between(int(p[0]), int(p[1])),
                                   House.region_id == r).all()
    else:
        house = House.query.filter(House.isActive=='已上架', House.city_id == c_id,
                                   House.acreage.between(int(a[0]), int(a[1])),
                                   House.price.between(int(p[0]), int(p[1]))
                                   ).all()
    l = []
    for h in house:
        l.append(h.to_dict())
    jsonStr = json.dumps(l)
    return jsonStr