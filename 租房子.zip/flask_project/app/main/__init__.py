# mian :　处理与网站相关的业务逻辑(主业务)
# 如: 发表房源、更新房源、查看房源、....
# 将自己添加到蓝图中
from flask import Blueprint
main = Blueprint("main", __name__)
from . import views