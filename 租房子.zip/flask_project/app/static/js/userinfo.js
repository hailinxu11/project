$(function () {
    var isClick = true
    $('.b1').click(function () {
        if($('#user').css('display')==('block')){
            $('#user').css('display','none')
        }else {
            $('#user').css('display','block')
        }
    })
    $('.b2').click(function () {
        if($('#order').css('display')==('block')){
            $('#order').css('display','none')
        }else {
            $('#order').css('display','block')
        }
    })
    $('.b3').click(function () {
        if($('#collect').css('display')==('block')){
            $('#collect').css('display','none')
        }else {
            $('#collect').css('display','block')
        }
    })
    $('.b4').click(function () {
        if($('#myhouse').css('display')==('block')){
            $('#myhouse').css('display','none')
        }else {
            $('#myhouse').css('display','block')
        }
    })

   // 关闭支付窗口
    $('#close').click(function () {
        $('#pay').css('display','none')
        $('.pay').css('display','none')
        $('body').css('overflow','auto')
    })

    //支付
    $('#payorder').click(function () {
        $('.pay').css('display','block')
        $('#pay').css('display','block')
        $('body').css('overflow','hidden')
        $('html').css('overflow','hidden')
    })

    // 监听付款，点击付款成功并修改房源状态跟订单状态
    $('#paybtn').click(function () {
        var id = $('#houseid').val()
        $.ajax({
            url:'/pay',
            type:'get',
            data:'id='+id,
            success:function (res) {
                if(res == '200'){
                    alert('付款成功')
                    location.href='/userinfo'
                }else {
                    alert('付款失败')
                    location.href='/userinfo'
                }
            }
        })
    })

})