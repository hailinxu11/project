$(function () {
    // 处理默认首页的房源图片
    function imgsrc(){
        var inpts = $('.srclist')
        for(var i=0;i<inpts.length;i++){
            var srclist = $(inpts)[i].value
            var src = srclist.split(',')
            var img = $(inpts[i]).next()
            img.attr('src',src[0])
        }
    }
    imgsrc()

    $('#check1>li').click(function () {
        $(this).addClass('clickson')
        $(this).siblings().removeClass('clickson')
        var acre = $(this).attr('acre')
        $('#acre').html(acre)
    })

    $('#check2>li').click(function () {
        $(this).addClass('clickson')
        $(this).siblings().removeClass('clickson')
        var price = $(this).attr('price')
        $('#prices').html(price)
    })

    $('#check3>li').click(function () {
        $(this).addClass('clickson')
        $(this).siblings().removeClass('clickson')
        var type = $(this).val()
        $('#type').html(type)
    })

    $('.click').on('click','#re',function () {
        $(this).addClass('clickson')
        $(this).siblings().removeClass('clickson')
        var city = $('#city_id').val()
        var re = $(this).val()
        $('#region').html(re)
        var acre = $('#acre').html()
        var price = $('#prices').html()
        var type = $('#type').html()
        var region = $('#region').html()
        $.ajax({
            url:'/queryby',
            type:'get',
            data:'a='+acre+'&p='+price+'&t='+type+'&r='+region+'&cid='+city,
            dataType:'json',
            success:function (res) {
                console.log(res);
                if(res=='') {
                    $('#house').html('<h1 style="text-align: center">没有匹配到您查找的条件</h1>')
                }else {
                    var house = ''
                    $.each(res ,function (n ,h) {
                        var imgs = h.images
                        var photo  = imgs.split(',')
                        console.log(img);
                        house +='<div class="house">\n' +
                                    '<div class="photo">\n' +
                                        '<img src="'+photo[0]+'">\n' +
                                    '</div>\n' +
                                    '<div class="details">\n' +
                                        '<h2>'+h.title+'</h2>\n' +
                                        '<p id="pin1">房屋类型：'+h.type+'</p>\n' +
                                        '<p id="pin1">房屋面积：'+h.acreage+'平方</p>\n' +
                                        '<p id="pin2">付款方式：'+h.payment+'</p>\n' +
                                        '<ul>\n' +
                                            '<li>'+h.advantage+'</li>\n' +
                                        '</ul>\n' +
                                    '</div>\n' +
                                    '<div class="price">\n' +
                                        '<p id="price">¥'+h.price+'</p>\n' +
                                        '<p id="but">\n' +
                                            '<a href="/details?id='+h.id+'" id="'+h.id+'" class="btn">点击查看详情</a>\n' +
                                        '</p>\n' +
                                    '</div>\n' +
                                '</div>'
                    })
                    $('#house').html(house)
                }
            }
        })
    })

    // 发送条件至后台
    $('.click>li').click(function () {
        var acre = $('#acre').html()
        var price = $('#prices').html()
        var type = $('#type').html()
        var region = $('#region').html()
        var city = $('#city_id').val()
        $.ajax({
            url:'/queryby',
            type:'get',
            data:'a='+acre+'&p='+price+'&t='+type+'&r='+region+'&cid='+city,
            dataType:'json',
            success:function (res) {
                console.log(res);
                if(res=='') {
                    $('#house').html('<h1 style="text-align: center">没有匹配到您查找的条件</h1>')
                }else {
                    var house = ''
                    $.each(res ,function (n ,h) {
                        var imgs = h.images
                        var photo  = imgs.split(',')
                        house +='<div class="house">\n' +
                                    '<div class="photo">\n' +
                                        '<img src="'+photo[0]+'">\n' +
                                    '</div>\n' +
                                    '<div class="details">\n' +
                                        '<h2>'+h.title+'</h2>\n' +
                                        '<p id="pin1">房屋类型：'+h.type+'</p>\n' +
                                        '<p id="pin1">房屋面积：'+h.acreage+'平方</p>\n' +
                                        '<p id="pin2">付款方式：'+h.payment+'</p>\n' +
                                        '<ul>\n' +
                                            '<li>'+h.advantage+'</li>\n' +
                                        '</ul>\n' +
                                    '</div>\n' +
                                    '<div class="price">\n' +
                                        '<p id="price">¥'+h.price+'</p>\n' +
                                        '<p id="but">\n' +
                                            '<a href="/details?id='+h.id+'" id="'+h.id+'" class="btn">点击查看详情</a>\n' +
                                        '</p>\n' +
                                    '</div>\n' +
                                '</div>'
                    })
                    $('#house').html(house)
                }
            }
        })
    })

    //选择省
    $('#pro_id').change(function () {
        var id = $(this).val()
        var url = '/01-upload?id='+id
        var xhr = createXhr()
        xhr.open('get',url,true)
        xhr.onreadystatechange = function () {
            if(xhr.readyState==4&&xhr.status==200){
                var city = xhr.responseText
                var obj = JSON.parse(city)
                var ci = '<option value="0">城市</option>'
                $.each(obj,function (n ,c) {
                    ci += '<option value="'+c.id+'">'+c.name+'</option>'
                })
                $('#city_id').html(ci)
            }
        }
        xhr.send(null)
    })

    // 选择市
    $('#city_id').change(function () {
        var xhr = createXhr()
        var id = $(this).val()
        var url = '/02-upload?id=' + id
        xhr.open('get', url, true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var region = xhr.responseText
                var obj = JSON.parse(region)
                var re = '<li class="clickson" value="0" id="re">不限</li>'
                $.each(obj, function (n, r) {
                    re += '<li id="re" value="' + r.id + '">' + r.name + '</li>'
                })
                $('#check').html(re)
            }
        }
        xhr.send(null)
    })

    // 选择城市获取房源
    $('#city_id').change(function () {
        var id = $(this).val()
        $.ajax({
            url:'/',
            type:'post',
            data:'id='+id,
            dataType:'json',
            async:true,
            success:function (res) {
                if(res=='') {
                    $('#house').html('<h1 style="text-align: center">没有匹配到您查找的条件</h1>')
                }else {
                    var house = ''
                    $.each(res ,function (n ,h) {
                        var imgs = h.images
                        var photo  = imgs.split(',')
                        house +='<div class="house">\n' +
                                    '<div class="photo">\n' +
                                        '<img src="'+photo[0]+'">\n' +
                                    '</div>\n' +
                                    '<div class="details">\n' +
                                        '<h2>'+h.title+'</h2>\n' +
                                        '<p id="pin1">房屋类型：'+h.type+'</p>\n' +
                                        '<p id="pin1">房屋面积：'+h.acreage+'平方</p>\n' +
                                        '<p id="pin2">付款方式：'+h.payment+'</p>\n' +
                                        '<ul>\n' +
                                            '<li>'+h.advantage+'</li>\n' +
                                        '</ul>\n' +
                                    '</div>\n' +
                                    '<div class="price">\n' +
                                        '<p id="price">¥'+h.price+'</p>\n' +
                                        '<p id="but">\n' +
                                            '<a href="/details?id='+h.id+'" id="'+h.id+'" class="btn">点击查看详情</a>\n' +
                                        '</p>\n' +
                                    '</div>\n' +
                                '</div>'
                    })
                    $('#house').html(house)
                }
            }
        })
    })

    // 监听搜索框输入
    $('.search').keyup(function () {
        $('#desc').html('')
        var res = $(this).val()
        var city = $('#city_id').val()
        $.ajax({
            url:'/query',
            type: 'get',
            data: 'data='+res+'&city='+city,
            async:'false',
            dataType:'json',
            success:function (obj) {
                if(obj=='1'){
                    console.log(obj);
                }else {
                    re = ''
                    $.each(obj,function (n ,r) {
                       re += '<li style="margin: 10px;" id="region">'+r.title+'</li>'
                    })
                    $('#desc').append(re)
                    $('#desc').append().css('display','block')
                }
            }
        })
    })

    // 监听动态添加的ul
    $('#desc').on('click','#region',function () {
        var res = $(this).html()
        $('.search').val(res)
        $('#desc').css('display','none')
    })

    // 监听搜索款的值，并根据值查询房源
    $('#btn').click(function () {
        var date = $('.search').val()
        $.ajax({
            url:'/queryhouse',
            type:'get',
            data:'date='+date,
            dataType:'json',
            success:function (res) {
                if(res=='') {
                    $('#house').html('<h1 style="text-align: center">没有匹配到您查找的条件</h1>')
                }else {
                    var house = ''
                    $.each(res ,function (n ,h) {
                        var imgs = h.images
                        var photo  = imgs.split(',')
                        house +='<div class="house">\n' +
                                    '<div class="photo">\n' +
                                        '<img src="'+photo[0]+'">\n' +
                                    '</div>\n' +
                                    '<div class="details">\n' +
                                        '<h2>'+h.title+'</h2>\n' +
                                        '<p id="pin1">房屋类型：'+h.type+'</p>\n' +
                                        '<p id="pin1">房屋面积：'+h.acreage+'平方</p>\n' +
                                        '<p id="pin2">付款方式：'+h.payment+'</p>\n' +
                                        '<ul>\n' +
                                            '<li>'+h.advantage+'</li>\n' +
                                        '</ul>\n' +
                                    '</div>\n' +
                                    '<div class="price">\n' +
                                        '<p id="price">¥'+h.price+'</p>\n' +
                                        '<p id="but">\n' +
                                            '<a href="/details?id='+h.id+'" id="'+h.id+'" class="btn">点击查看详情</a>\n' +
                                        '</p>\n' +
                                    '</div>\n' +
                                '</div>'
                    })
                    $('#house').html(house)
                }
            }
        })
    })




    // 2.轮播图
    //eq(index) 获取指定下标的元素
    var imgIndex = 0;
    var timerID = setInterval(autoPlay,3000);
    function autoPlay(){
        //隐藏图片
        $("#banner img").each(function (){
            $(this).css("display","none");
        })
        //更新下标
        imgIndex = ++ imgIndex == $("#banner img").length ? 0 :imgIndex;
        //显示一张图片
        $("#banner img").eq(imgIndex).css("display",'block');

        //图片索引
        $("#banner li").each(function(){
            $(this).css("background","#e8e8e0");
        })
        //跟随图片显示背景色
        $("#banner li").eq(imgIndex).css("background","#f70434");

    }
    //鼠标移入，停止定时器
    $("banner").bind("mouseover",function(){
        clearInterval(timerID);
    })
    //鼠标移出，继续轮播
    $("banner").mouseout(function (){
        var timerID = setInterval(autoPlay,1000);
    })


})