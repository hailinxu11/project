$(function () {

    //获取城市
    $('#pro').change(function () {
        var xhr = createXhr()
        var id = $(this).val()
        var url = '/01-upload?id='+id
        xhr.open('get',url,true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState==4&&xhr.status==200){
                var city = xhr.responseText
                var obj = JSON.parse(city)
                var op = '<option value="0">选择城市</option>'
                $.each(obj,function(n, c) {
                    op +='<option value="'+c.id+'">'+c.name+'</option>'
                })
                $('#city').html(op)
            }
        }
        xhr.send(null)
    })

    //获取区域
    $('#city').change(function () {
        var xhr = createXhr()
        var id = $(this).val()
        var url = '/02-upload?id='+id
        xhr.open('get',url,true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState==4&&xhr.status==200){
                var region = xhr.responseText
                var obj = JSON.parse(region)
                var re = '<option value="0">选择区域</option>'
                $.each(obj,function(n, r) {
                    re +='<option value="'+r.id+'">'+r.name+'</option>'
                })
                $('#region').html(re)
            }
        }
        xhr.send(null)
    })

    // 上传房源
    $('#bttn').click(function () {
        var img = document.getElementById('imgs')
        var lien = img.files.length
        var formDa = new FormData($('.upload')[0])
        var l = new Array()
        for (var i = 0; i < lien; i++) {
            var temp = img.files[i]
            formDa.append('photos',l)
        }
        console.log(formDa.getAll('photos'));
        $.ajax({
            url:'/03-upload',
            type:'post',
            data:formDa,
            async: false,
            cache: false,
            contentType: false,
            processData: false,
            success:function (res) {
                if(res == 1){
                    alert('上传房源成功！')
                    location.href='/'
                }else {
                    alert('上传房源失败！')
                    location.href='/upload'
                }
            }
        })
    })

    // 上传图片预览
    $('#imgs').click()
    $("#imgs").on("change", function () {
        var length = this.files.length;
        if(length>8){
            alert('最多上传8张图片')
        }else {
            var imgs = ''
            for (var i = 0; i < length; i++) {
                var temp = this.files[i].name;
                var te = this.files[i]
                var read = new FileReader()
                read.readAsDataURL(te)
                read.onload = function (e) {
                    imgs += '<img src="' + e.target.result + '" class="preview"/>'
                    $('#readimgs').empty().append(imgs)
                }
            }
        }

    })
})