$(function () {
    $('#upuser').click(function () {
        // var id= $('#userid').val()
        // var upwd = $('input[name=upwd]').val()
        // var newpwd1 = $('input[name=newpwd1]').val()
        // var newpwd2 = $('input[name=newpwd2]').val()
        $.ajax({
            url:'/upuser',
            type:'post',
            data:$('#upuserinfo').serialize(),
            success:function (res) {
                if(res=='0'){
                    alert('密码修改成功')
                    location.href='/userinfo'
                }else if(res=='1'){
                    alert('两次密码不一致')
                }else {
                    alert('原始密码错误')
                }
            }
        })
    })
})