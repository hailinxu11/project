$(function(){

    function cill(){
        // 检测是否收藏
        var hid = $('#houseid').val()
        $.ajax({
            url:'/iscoll',
            type:'get',
            data:'hid='+hid,
            success:function (res) {
                if(res == '0'){
                    $('#collection_1').css('display','none')
                    $('#collection_2').css('display','block')
                }else {
                    $('#collection_1').css('display','block')
                    $('#collection_2').css('display','none')
                }
            }
        })
    }
    cill()

    $('#details_img img').first().addClass('displays')
    $('.right').click(function(){
        var imgs = $('this').siblings('img')
        var img = $('.displays')
        $(img).next().addClass('displays')
        $(img).next().siblings().removeClass('displays')
    })
    $('.left').click(function () {
        var img = $('.displays')
        $(img).prev().addClass('displays')
        $(img).prev().siblings().removeClass('displays')
    })
    $('#btnphone').click(function () {
        $('#phone').css('display','block')
        $(this).css('display','none')
    })
    $('#phone').click(function () {
        $(this).append().css('display','none')
        $('#btnphone').css('display','block')
    })
    // 创建订单
    $('#btnorder').click(function () {
        var hid = $('#houseid').val()
        var mon = $('#money').html()
        console.log(mon);
        var money = mon.replace(/[^0-9]/ig,'')
        console.log(money);
        $.ajax({
            url:'/btnorder',
            type:'get',
            data:'h_id='+hid+'&money='+money,
            success:function (res) {
                if(res == '1'){
                    alert('请先登录')
                    location='/login'
                }else if(res == '0'){
                    $('.pay').css('display','block')
                    $('#pay').css('display','block')
                    $('body').css('overflow','hidden')
                    $('html').css('overflow','hidden')
                }
            }
        })
    })

    // 关闭支付窗口
    $('#close').click(function () {
        $('#pay').css('display','none')
        $('.pay').css('display','none')
        $('body').css('overflow','auto')
        $('html').css('overflow','auto')
    })

    // 监听付款，点击付款成功并修改房源状态跟订单状态
    $('#paybtn').click(function () {
        var id = $('#houseid').val()
        $.ajax({
            url:'/pay',
            type:'get',
            data:'id='+id,
            success:function (res) {
                if(res == '200'){
                    alert('付款成功')
                    location.href='/'
                }else {
                    alert('付款失败')
                    location.href='/'
                }
            }
        })
    })

    // 绑定收藏点击事件发送数据至后台做收藏处理（创建收藏）
    $('#collection_1').click(function () {
        var hid = $('#houseid').val()
        $.ajax({
            url:'/createcoll',
            type:'get',
            data:'hid='+hid,
            dataType:'json',
            success:function (res) {
                if(res == '1'){
                    alert('请先登录')
                    location.href='/login'
                }else {
                    $('#collection_1').css('display','none')
                    $('#collection_2').css('display','block')
                }
            }
        })
    })

    // 取消收藏
    $('#collection_2').click(function () {
        $(this).css('display','none')
        $('#collection_1').css('display','block')
        var hid = $('#houseid').val()
        $.ajax({
            url:'/delcoll',
            type:'get',
            data:'hid='+hid,
            dataType:'json',
            success:function (res) {
                if(res == '1'){
                    alert('请先登录')
                    location.href='/login'
                }
            }
        })
    })

})