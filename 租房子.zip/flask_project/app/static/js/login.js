$(function () {
    $('#user_login').click(function () {
        var loginid = $('input[name=loginid]').val()
        var pwd = $('input[name=upwd]').val()
        if (loginid == ''||pwd==''){
            $('input[name=loginid]').html('用户名不能为空')
            $('input[name=upwd]').html('密码不能为空')
        }
        $.ajax({
            url:'/login',
            type:'post',
            data:$('#login').serialize(),
            success:function (res) {
                console.log(res);
                if(res=='1'){
                    alert('账号或密码错误')
                    location.href='/login'
                }else if(res == '0'){
                    self.location = document.referrer
                } else {
                    alert('用户不存在')
                    location.href='/login'
                }
            }
        })
    })
})