$(function () {
    //验证账号
    $('input[name=loginid]').blur(function () {
        var url = 'id='+$(this).val()
        var xhr = createXhr()
        xhr.open('post','/01-register',true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState==4&&xhr.status==200){
                if(xhr.responseText == '0'){
                    $('#alert').html('❌用户已存在')
                }else if(xhr.responseText == '1'){
                    $('#alert').html('✅通过')
                }else {
                    $('#alert').html('❌不能为空')
                }
            }
        }
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
        xhr.send(url)
    })

    //验证昵称
    $('input[name=uname]').blur(function () {
        var url = 'name='+$(this).val()
        var xhr = createXhr()
        xhr.open('post','/02-register',true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState==4&&xhr.status==200){
                if(xhr.responseText == '0'){
                    $('#name').html('❌昵称已存在')
                }else if(xhr.responseText == '1'){
                    $('#name').html('✅通过')
                }else {
                    $('#name').html('❌不能为空')
                }
            }
        }
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
        xhr.send(url)
    })

    //验证密码是否一致
    $('input[name=upwd]').blur(function () {
        var pwd = $(this).parent().prev().find('input').val()
        var url = 'pwd='+pwd+'&upwd='+$(this).val()
        var xhr = createXhr()
        xhr.open('post','/03-register',true)
        xhr.onreadystatechange = function () {
            if (xhr.readyState==4&&xhr.status==200){
                if(xhr.responseText == '0'){
                    $('#pwd').html('❌密码不一致')
                }else if(xhr.responseText == '1'){
                    $('#pwd').html('✅通过')
                }else {
                    $('#upwd').html('❌不能为空')
                }
            }
        }
        xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded')
        xhr.send(url)
    })

    // 判断是否注册成功并提示
    $('#buttn').click(function () {
        console.log($('#forms').serialize());
        $.ajax({
            url:'/register',
            type: 'post',
            data: $('#forms').serialize(),
            success:function (res) {
                console.log('aa');
                if(res=='0'){
                    alert('注册成功')
                    location.href = '/login'
                }else if(res=='1'){
                    alert('不能为空')
                }else if(res=='2'){
                    alert('请阅读协议')
                }else if(res=='3'){
                    $('#msg').css('border','1px solid red')
                }
            }
        })
    })

    // 设置获取验证码默认不能点击
    $('input[name=loginid]').blur(function () {
        var phone = $(this).val().length
        if(phone != 11){
            $("#btnmsg").attr({"disabled":"disabled"});
            $('#btnmsg').css('background','#8e8b87');
        }else {
            $("#btnmsg").removeAttr("disabled");
            $('#btnmsg').css('background','#e88904');
        }
    })

    // 获取验证码，后台验证码的输入是否正确并返回值
    $('#btnmsg').click(function () {
        var phone = $('input[name=loginid]').val()
        $.ajax({
            url:'/04-register',
            type:'post',
            data:'msg='+phone,
            success:function (res) {
                if(res =='400'){
                    $('#btnmsg').val('发送失败')
                }else {
                    var time = 60
                    console.log(time);
                    $("#btnmsg").attr({"disabled":"disabled"});
                    $('#btnmsg').css('background','#8e8b87');
                    setInterval(function () {
                        time--
                        if(time <= 0){
                            $("#btnmsg").removeAttr("disabled");
                            $('#btnmsg').css('background','#e88904');
                            $('#btnmsg').val('重新获取')
                        }else {
                            $('#btnmsg').val(time+'秒')
                        }
                    },1000)
                }
            }
        })
    })
})

