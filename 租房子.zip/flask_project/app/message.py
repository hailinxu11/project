import urllib.request,json,random
from urllib import parse


class Message(object):
    def __init__(self,mobile,val):
        self.mobile = mobile
        self.value = val

    def send(self):
        # s = random.sample('1234567890', 4)
        # val = ''.join(s)
        value = '#code#='+self.value
        appkey = 'e1699e21cb1d087609e3e631bb4a28ac'  # 您申请的短信服务appkey
        tpl_id = '146313'  # 申请的短信模板ID,根据实际情况修改
        sendurl = 'http://v.juhe.cn/sms/send'  # 请求发送短信的地址
        params = 'key=%s&mobile=%s&tpl_id=%s&tpl_value=%s' % (appkey, self.mobile, tpl_id, parse.quote(value))
        wp = urllib.request.urlopen(sendurl + '?' + params)
        content = wp.read()
        result = json.loads(content)
        if result:
            error_code = result['error_code']
            if error_code == 0:
                smsid = result['result']['sid']
                return '200'
            else:
                # 发送失败
                return '500'
        else:
            # 请求失败
            return '404'


