# 当前程序的初始化
# 1. 创建flask应用(app)以及各种配置;
# 2. 创建SQLAlchemy的应用实例(db);
# 3.
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
# 声明SQLAlchemy的实例
db = SQLAlchemy()

def create_app():
    # 创建flask的程序实例 - app
    app = Flask(__name__)
    # 为app指定各种配置
    app.config["DEBUG"] = True
    # 为app指定数据库的配置
    app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:123456@localhost:3306/house"
    app.config["SQLALCHEMY_COMMIT_ON_TEARDOWN"] = True
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    # 配置session所需要的secret_key
    app.config["SECRET_KEY"] = "suibianxie"
    # 关联db以及app
    db.init_app(app)
    # 将main蓝图与app关联在一起(让app托管main,users)
    from . main import main as main_blueprint
    from . user import user as user_blueprint
    from . order import order as order_blueprint
    # 让app托管main users
    app.register_blueprint(main_blueprint)
    app.register_blueprint(user_blueprint)
    app.register_blueprint(order_blueprint)
    # 返回创建好的程序实例app
    return app