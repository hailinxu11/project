from . import db

# 创建租客实体类
class Users(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    # 用户登录账号
    loginid = db.Column(db.String(20),nullable=False,unique=True)
    # 用户昵称
    name = db.Column(db.String(20),unique=True,default=loginid)
    # 用户密码
    pwd = db.Column(db.String(50),nullable=False)
    # 用户邮箱
    email = db.Column(db.String(50),nullable=False)
    # 租客与订单是一对多关系
    orders = db.relationship("Order",backref="users", lazy="dynamic")
    # 租客与收藏是多对多的关系
    collects = db.relationship('Collect',backref="users", lazy="dynamic")

# 创建房东实体类（参考租客类）
class Landlord(db.Model):
    __tablename__ = 'landlord'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    loginid = db.Column(db.String(20), nullable=False, unique=True)
    name = db.Column(db.String(20), unique=True, default=loginid)
    pwd = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), nullable=False)
    # 房东与房源一对多关系
    houses = db.relationship("House",backref="landlord", lazy="dynamic")
    # 房东与订单一对多关系
    orders = db.relationship("Order", backref="landlord", lazy="dynamic")

# 创建省份类别
class Province(db.Model):
    __tablename__ = 'province'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    name = db.Column(db.String(30),unique=True)
    citys = db.relationship("City",backref="province", lazy="dynamic")

# 创建城市类别
class City(db.Model):
    __tablename__ = 'city'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    name = db.Column(db.String(30),unique=True)
    # 与省份建立一对多关系
    pro_id = db.Column(db.Integer,db.ForeignKey('province.id'))
    house = db.relationship("House", backref="city", lazy="dynamic")

# 创建房源实体类
class House(db.Model):
    __tablename__ = 'house'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    # 标题
    title = db.Column(db.String(100),nullable=False)
    # 面积
    acreage = db.Column(db.Integer,nullable=False)
    # 租金
    price = db.Column(db.Integer,nullable=False)
    # 付款方式
    payment = db.Column(db.String(20),nullable=False)
    # 图片
    images = db.Column(db.Text)
    # 户型
    type = db.Column(db.String(20),nullable=False)
    # 楼层
    floor = db.Column(db.String(20),nullable=False)
    # 房屋配置
    configure = db.Column(db.String(100),nullable=False)
    # 房屋优势
    advantage = db.Column(db.String(100),nullable=False)
    # 朝向
    orientation = db.Column(db.String(20),nullable=False)
    # 详细地址
    address = db.Column(db.String(200),nullable=False)
    # 联系电话
    phone = db.Column(db.Integer,nullable=False)
    # 时间
    time = db.Column(db.DateTime,nullable=False)
    # 房源状态
    status = db.Column(db.Boolean,default=True, nullable=False)
    # 所属省份
    pro_id = db.Column(db.Integer,db.ForeignKey('province.id'))
    # 所属城市
    city_id = db.Column(db.Integer,db.ForeignKey('city.id'))
    # 房东
    landlord_id = db.Column(db.Integer,db.ForeignKey('landlord.id'))
    def to_dict(self):
        dic = {
            'id':self.id,
            'title':self.title,
            'acreage':self.acreage,
            'price':self.price,
            'payment':self.payment,
            'images':self.images,
            'type':self.type,
            'floor':self.floor,
            'configure':self.configure,
            'orientation':self.orientation,
            'address':self.address,
            'phone':self.phone,
            'time':self.time,
            'status':self.status,
            'user_id':self.user_id,
            'pro_id':self.pro_id,
            'city_id':self.city_id
        }
        return dic

# 创建订单实体类
class Order(db.Model):
    __tablename__ = 'order'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    house_id = db.Column(db.Integer,db.ForeignKey('house.id'))
    user_id = db.Column(db.Integer,db.ForeignKey('users.id'))
    landlord_id = db.Column(db.Integer,db.ForeignKey('landlord.id'))
    # 订单状态（已支付、未支付、已取消）默认为未支付
    status = db.Column(db.String(20), default="未支付", nullable=False)
    # 订单创建时间
    time = db.Column(db.DateTime,nullable=False)

# 创建收藏房源实体类
class Collect(db.Model):
    __tablename__ = 'cart'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    user_id = db.Column(db.Integer,db.ForeignKey('users.id'))
    house_id = db.Column(db.Integer,db.ForeignKey('house.id'))

