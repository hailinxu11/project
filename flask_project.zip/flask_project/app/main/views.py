# 处理商城首页的显示与其他业务
import datetime
import json
import os

from .. models import *
from flask import render_template, session, request, redirect
from . import main

# 首页视图
@main.route("/")
def index_views():
    pros = Province.query.all()
    citys = City.query.filter(City.pro_id==1)
    if "name" in session:
        uname = session["name"]
    return render_template("index.html",params = locals())

@main.route('/upload',methods=["GET", "POST"])
def register_views():
    if request.method == 'GET':
        return render_template('upload.html')
    else:
        pass

