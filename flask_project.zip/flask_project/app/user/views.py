import datetime
import json
import os

from .. models import *
from flask import render_template, session, request, redirect
from . import user

@user.route('/register',methods=['GET','POST'])
def register_views():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        pass


@user.route('/login',methods=['GET','POST'])
def login_views():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        pass


