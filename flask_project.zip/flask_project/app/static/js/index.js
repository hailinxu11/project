$(function () {
    $('.click>li').click(function () {
        $(this).addClass('clickson')
        $(this).siblings().removeClass('clickson')
    })
})