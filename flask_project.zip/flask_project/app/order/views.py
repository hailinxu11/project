import datetime
import json
import os

from .. models import *
from flask import render_template, session, request, redirect
from . import order

@order.route('/details')
def details_views():
    return render_template('details.html',params=locals())